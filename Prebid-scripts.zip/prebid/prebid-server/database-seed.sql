CREATE TABLE stored_requests
(
    id uuid DEFAULT gen_random_uuid() PRIMARY KEY,
    requestdata text,
    created_on timestamp with time zone NOT NULL DEFAULT now()
);

insert into stored_requests(id, requestdata) values ('06489cdd-f544-4a61-b377-be6e9b5050f5','{ "cur": ["USD"], "ext": { "prebid": { "cache": { "bids": {} }, "targeting": { "includewinners": true, "pricegranularity": { "ranges": [{ "max": 20, "increment": 0.01 }], "precision": 2 }, "includebidderkeys": true } } }, "events": { "enabled": true }, "disabled": false, "cache_ttl": { "audio": 3600, "video": 3600, "banner": 600, "native": 3600 } }');

CREATE TABLE stored_imps
(
    id uuid DEFAULT gen_random_uuid() PRIMARY KEY,
    impdata text,
    created_on timestamp with time zone NOT NULL DEFAULT now()
);
insert into stored_imps(id, impdata) values ('cbbd553d-179e-430b-9d0a-f5bd4e416822','{ "banner": { "format": [ { "w": 300, "h": 250 }, { "w": 300, "h": 600 } ] }, "ext": { "prebid": { "bidder": { "appnexus": { "placement_id": 12883451 } } } } }');

CREATE TABLE stored_responses
(
    id uuid DEFAULT gen_random_uuid() PRIMARY KEY,
    responsedata text,
    created_on timestamp with time zone NOT NULL DEFAULT now()
);
insert into stored_responses(id, responsedata) values ('532042f9-46de-4478-8408-836d9fe4627f','[{
	"bid": [{
		"id": "06489cdd-f544-4a61-b377-be6e9b5050f5",
		"impid": "06489cdd-f544-4a61-b377-be6e9b5050f5",
		"price": 5,
		"adm": "<style> html, body  { margin: 0; padding: 0; width: 100%; height: 100%; vertical-align: middle; }  html  { display: table; }  body { display: table-cell; vertical-align: middle; text-align: center; -webkit-text-size-adjust: none; }  </style> <span class=\"title-link advertiser_label\"></span> <a href=\"https://appgallery.huawei.com/#/app_simple/C105624843\" style=\"text-decoration:none\" onclick=sendGetReq()> <img src=\"https://cs02-pps-dre.dbankcdn.com/dl/pps/20220721003915BDFBAF3609CB2CE3F5BA88BA7B4B0D1F.jpg\" width=\"320\" height=\"50\"/> </a> <img height=\"1\" width=\"1\" src=\"https://events-dre.op.hicloud.com/contserver/tracker/action?ch=200002&etype=imp&kn=2&pfsa=FNe7ribdxb4Tujdm8SiapJXFdicPandGRiatia4OGHTe9jSqH2Aldvf9IYrNSGfe529EsBzPJypDDZOiannSO8FMlxL3bNQCMia0u96G4IcOqDwAREKE4svvg20YmdeWWp6p1kicUw5ZNtZsFjkkW1SfGMrG0uGSyMeZWDRGKS8iaw3xicyy7qib7FsXCmFibzpkOvwoNNKdLrnOA7Mbv8ibZFtic8QPRjRvbIsr0SccsVOKnwstibO85UtEicFq6l0zRef5MsydVtwibyzDkoQkQctiaCo5icVib6rwJDlBACZgMMxofDGzuTnbEiby3wpiaQAZ2EgRY3CuCRJhkHUvqiaJSBTLD1PAdLtLY6bPohDyN6MaTkJn3KmRmicmBHPcC78DDmwgRybtrc1Mu27POhpeVYa1Eh3nB8PNSwAymGMe7GLsmfrZF1vJQjKRj4czl8CjElbdKxXvdesKwxvsWeE8UcXibfAFjdOtsUXH8Nmww7pp2zuwMBiaX3hX6WTpJVVj0rogEeJR48S9JQkCpGA9Bmgx1bQYsdoYjYAHc2GqRXPGDoXZfFqmicsfcZ0EicQSxiayjiblicS9d09b8eSslG19A2ibOWeJCMjzN7hXHkfqaP2JwkM9HGTOdJgygXxvSn9kvnau8b5C3DYF8lnD49mTiaTiaJsAdyry9WF4AiccBRZHKkDUOP9sGHM7kichic82WAr1Mu5U3PUZ5LwJfkpQdzPJTLD00MrYEwiaZLSFicUah0QkyzapbMuicicL9vKy8HiavyHBslqvHZOquDdzt3uv2Qt7YniafwduA&uuid=_UUID_\" >  <script type=\"text/javascript\">var dspClickTrackings = [\"https://events-dre.op.hicloud.com/contserver/tracker/action?ch=200002&etype=click&kn=2&pfsa=FNe7ribdxb4Tujdm8SiapJXFdicPandGRiatia4OGHTe9jSqH2Aldvf9IYrNSGfe529EsBzPJypDDZOiannSO8FMlxL3bNQCMia0u96G4IcOqDwAREKE4svvg20YmdeWWp6p1kicUw5ZNtZsFjkkW1SfGMrG0uGSyMeZWDRGKS8iaw3xicyy7qib7FsXCmFibzpkOvwoNNKdLrnOA7Mbv8ibZFtic8QPRjRvbIsr0SccsVOKnwstibO85UtEicFq6l0zRef5MsydVtwibyzDkoQkQctiaCo5icVib6rwJDlBACZgMMxofDGzuTnbEiby3wpiaQAZ2EgRY3CuCRJhkHUvqiaJSBTLD1PAdLtLY6bPohDyN6MaTkJn3KmRmicmBHPcC78DDmwgRybtrc1Mu27POhpeVYa1Eh3nB8PNSwAymGMe7GLsmfrZF1vJQjKRj4czl8CjElbdKxXvdesKwxvsWeE8UcXibfAFjdOtsUXH8Nmww7pp2zuwMBiaX3hX6WTpJVVj0rogEeJR48S9JQkCpGA9Bmgx1bQYsdoYjYAHc2GqRXPGDoXZfFqmicsfcZ0EicQSxiayjiblicS9d09b8eSslG19A2ibOWeJCMjzN7hXHkfqaP2JwkM9HGTOdJgygXxvSn9kvnau8b5C3DYF8lnD49mTiaTiaJsAdyry9WF4AiccBRZHKkDUOP9sGHM7kichic82WAr1Mu5U3PUZ5LwJfkpQdzPJTLD00MrYEwiaZLSFicUah0QkyzapbMuicicL9vKy8HiavyHBslqvHZOquDdzt3uv2Qt7YniafwduA&uuid=_UUID_&w=__HW_W__&h=__HW_H__&downx=__HW_DOWN_X__&downy=__HW_DOWN_Y__&upx=__HW_UP_X__&upy=__HW_UP_Y__\"];function sendGetReq() {sendSomeGetReq(dspClickTrackings)}function sendOneGetReq(url) {var req = new XMLHttpRequest();req.open(\"GET\", url, true);req.send(null);}function sendSomeGetReq(urls) {for (var i = 0; i < urls.length; i++) {sendOneGetReq(urls[i]);}}</script>",
		"adomain": [
			"huaweiads"
		],
		"crid": "58025103",
		"w": 320,
		"h": 50,
		"mtype": 1
	}],
	"seat": "huaweiads"
}]');